#pragma once
#include<iostream>
#include<string>
using namespace std;
class User
{
public:
	int userID;
	string username;
	string email;
	string Country;
	string Type;
	static int user_id;

public:
	User(string un = "", string em = "", string Ct = "", string T = "")
	{
		userID= user_id++;
		cout << "enter Username : ";
		getline(cin, username);
		cout << "enter email : ";
		getline(cin, email);
		cout << "enter country : ";
		getline(cin, Country);
		cout << "enter Type : ";
		getline(cin, Type);

		cout << endl << endl;
	}
	friend ostream& operator<<(ostream& , User*& );

};

int User::user_id = 0;
inline ostream& operator<<(ostream& out, User*& user)                         //operator<< to print a certain card;
{
	cout << "UserID : " << user->userID;
	cout << endl;
	cout << "Username : " << user->username;
	cout << endl;
	cout << "Email : " << user->email;
	cout << endl;
	cout << "Country : " << user->Country;
	cout << endl;
	cout << "Type : " << user->Type;
	cout << endl;
	return out;
}