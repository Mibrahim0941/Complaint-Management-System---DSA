#pragma once
#include<iostream>
#include<list>
#include<vector>
#include"3G-23L_0521-A4-Users.h"
#include"3G-23L_0521-A4-AVLTree.h"

class ChainHash
{
	struct Node
	{
		string data;
		list<User*>::iterator it;
        Node(string k, list<User*>::iterator i)
        {
            data = k;
            it = i;
        }
	};
	int size;
	int count;
	vector<list<Node*>*> Table;

	unsigned int hash(string key)
	{
		unsigned int hashVal = 0;
		for (char ch : key)
			hashVal = 37 * hashVal + ch;
		return hashVal % size;
	}

    void rehash()
    {
        int oldSize = size;
        size *= 2;
        vector<list<Node*>*> oldArr = Table;
        Table.resize(size);
        for (int i = 0; i < size; i++)
        {
            Table[i] = nullptr;
        }
        count = 0;
        for (int i = 0; i < oldSize; i++)
        {
            if (oldArr[i] != nullptr)
                for (list<Node*>::iterator ite = oldArr[i]->begin(); ite!=oldArr[i]->end(); ite++)
                {
                    Insert((*ite)->data, (*ite)->it);
                }
        }
    }

public:
    ChainHash(int s = 101)
    {
        size = s;
        count = 0;
        Table.resize(size);
        for (int i = 0; i < size; i++)
        {
            Table[i] = 0;
        }
    }

    void Insert(string key, list<User*> ::iterator it)
    {
        if ((float(count) / size) > 0.5)
        {
            rehash();
        }

        int hashIndex = hash(key);
        int i = 0;
        if (Table[hashIndex] == nullptr)
        {
            Table[hashIndex] = new list<Node*>;
        }
        Table[hashIndex]->push_back(new Node(key, it));
        count++;
    }

    void Delete(string key)
    {
        int hashIndex = hash(key);
        int i = 0;
        if (Table[hashIndex] != nullptr)
        {
            list<Node*>::iterator it = Table[hashIndex]->begin();
            if (Table[hashIndex]->size() == 1)
            {
                Table[hashIndex]->pop_back();
                Table[hashIndex] = nullptr;
            }
            else
            {
                for (; it != Table[hashIndex]->end(); it++)
                {
                    if ((*it)->data == key)
                    {
                        Table[hashIndex]->erase(it);
                    }
                }
            }
            count--;
        } 
    }

    void DeleteName(string key, ChainHash& email, UniversalHash<int>& uid )
    {
        int hashIndex = hash(key);
        int i = 0;
        if (Table[hashIndex] != nullptr)
        {
            list<User*>::iterator temp;
            list<Node*>::iterator it = Table[hashIndex]->begin();
            if (Table[hashIndex]->size() == 1)
            {
                temp = (*it)->it;

                Table[hashIndex]->pop_back();
                Table[hashIndex] = nullptr;
            }
            else
            {
                for (; it != Table[hashIndex]->end(); it++)
                {
                    if ((*it)->data == key)
                    {
                        temp = (*it)->it;
                        Table[hashIndex]->erase(it);
                    }
                }
            }
            count--;
            email.Delete((*temp)->email);
            uid.Delete((*temp)->userID);
        }
    }

    void DeleteEmail(string key, ChainHash& name, UniversalHash<int>& uid)
    {
        int hashIndex = hash(key);
        int i = 0;
        if (Table[hashIndex] != nullptr)
        {
            list<User*>::iterator temp;
            list<Node*>::iterator it = Table[hashIndex]->begin();
            if (Table[hashIndex]->size() == 1)
            {
                temp = (*it)->it;

                Table[hashIndex]->pop_back();
                Table[hashIndex] = nullptr;
            }
            else
            {
                for (; it != Table[hashIndex]->end(); it++)
                {
                    if ((*it)->data == key)
                    {
                        temp = (*it)->it;
                        Table[hashIndex]->erase(it);
                    }
                }
            }
            count--;
            name.Delete((*temp)->username);
            uid.Delete((*temp)->userID);
        }
    }

    User* Access(string key)
    {
        int hashIndex = hash(key);
        int i = 0;
        if (Table[hashIndex] != nullptr)
        {
            list<User*>::iterator temp;
            list<Node*>::iterator it = Table[hashIndex]->begin();
            if (Table[hashIndex]->size() == 1)
            {
                temp = (*it)->it;
            }
            else
            {
                for (; it != Table[hashIndex]->end(); it++)
                {
                    if ((*it)->data == key)
                    {
                        temp = (*it)->it;
                    }
                }
            }
            return (*temp);
        }
        return nullptr;
    }

    void print()
    {
        cout << "\n--------------------------------------------------------------------------------------------------\n\n";
        for (int i = 0; i < size; i++)
        {
            if (Table[i] != nullptr)
            {
                list<User*>::iterator temp;
                list<Node*>::iterator it = Table[i]->begin();
                if (Table[i]->size() == 1)
                {
                    temp = (*it)->it;
                }
                else
                {
                    for (; it != Table[i]->end(); it++)
                    {
                         temp = (*it)->it;
                         cout << (*temp)<<endl;
                    }
                }
                cout<< (*temp)<<endl;
            }
        }
        cout << "\n\n--------------------------------------------------------------------------------------------------\n";
    }
};

