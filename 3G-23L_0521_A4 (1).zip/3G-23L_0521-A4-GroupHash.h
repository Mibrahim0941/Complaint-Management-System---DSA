#pragma once

#include<iostream>
#include<list>
#include<vector>
#include"3G-23L_0521-A4-Users.h"
#include"3G-23L_0521-A4-AVLTree.h"
#include"3G-23L_0521-A4-ChainHash.h"
#include"3G-23L_0521-A4-complaints.h"
template<typename T, typename T2>
class GroupHash
{
    struct Node
    {
        T data;
        /*list<User*>::iterator*/T2 it;
        Node(T k, T2 i)
        {
            data = k;
            it = i;

        }
    };
    int size;
    int count;
    int collisionMethod;
    int prime;
    vector<list<Node*>*> Table;

    unsigned int hash(string key)
    {
        unsigned int hashVal = 0;
        for (char ch : key)
            hashVal = 37 * hashVal + ch;
        return hashVal % size;
    }

    int hash(int key)
    {
        srand(key);
        int a = rand();
        int b = rand();
        return ((a * key + b) % prime) % size;
    }

    void rehash()
    {
        int oldSize = size;
        size *= 2;
        vector<list<Node*>*> oldArr = Table;
        Table.resize(size);
        for (int i = 0; i < size; i++)
        {
            Table[i] = nullptr;
        }
        count = 0;
        for (int i = 0; i < oldSize; i++)
        {
            if (oldArr[i] != nullptr)
                for (typename list<Node*>::iterator ite = oldArr[i]->begin(); ite != oldArr[i]->end(); ite++)
                {
                    Insert((*ite)->data, (*ite)->it);
                }
        }
    }

public:
    GroupHash( int method = 0 ,int s = 101)
    {
        prime = 1009;
        collisionMethod = method;
        size = s;
        count = 0;
        Table.resize(size);
        for (int i = 0; i < size; i++)
        {
            Table[i] = 0;
        }
    }


    void setMethod(int m)
    {
        collisionMethod = m;
    }

    void Insert(T key, T2 it)
    {
        if ((float(count) / size) > 0.5)
        {
            rehash();
        }

        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            switch (collisionMethod)
            {
            case 1:
                probeIndex = (hashIndex + i) % size;
                break;
            case 2:
                probeIndex = (hashIndex + i * i) % size;
                break;
            }
            if (Table[probeIndex] == nullptr)
            {
                Table[probeIndex] = new list<Node*>;
                Table[probeIndex]->push_back(new Node(key, it));
                count++;
                return;
            }
            else
            {
                typename list<Node*>::iterator ite = Table[probeIndex]->begin();
                if ((*ite)->data == key)
                {
                    Table[probeIndex]->push_back(new Node(key, it));
                    count++;
                    return;
                }

            }
            i++;
        }
            
    }

    list<User*>* Delete(T key)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            switch (collisionMethod)
            {
            case 1:
                probeIndex = (hashIndex + i) % size;
                break;
            case 2:
                probeIndex = (hashIndex + i * i) % size;
                break;
            }

            if (Table[probeIndex] != nullptr)
            {
                typename list<Node*>::iterator it = Table[probeIndex]->begin();
                if((*it)->data == key)
                {
                    list<User*>* templist= new list<User*>;
                    while (it != Table[probeIndex]->end())
                    {
                        templist->push_back((*((*it)->it)));
                        it++;
                    }
                    count = count - Table[probeIndex]->size();
                    Table[probeIndex]->clear();
                    Table[probeIndex] = nullptr;
                    return templist;
                }
            }
            i++;
        }
        return nullptr;
    }

    void Delete(T key, string temp)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            switch (collisionMethod)
            {
            case 1:
                probeIndex = (hashIndex + i) % size;
                break;
            case 2:
                probeIndex = (hashIndex + i * i) % size;
                break;
            }

            if (Table[probeIndex] != nullptr)
            {
                typename list<Node*>::iterator it = Table[probeIndex]->begin();
                if ((*it)->data == key)
                {
                    while (it != Table[probeIndex]->end())
                    {
                        if ((*((*it)->it))->username == temp || (*((*it)->it))->email == temp)
                        {
                            Table[probeIndex]->erase(it);
                            count--;
                            if (Table[probeIndex]->size() == 0)
                                Table[probeIndex] = nullptr;
                            return;
                        }
                    }
                }
            }
            i++;
        }
    }

    template<typename T3>
    void Access(T key)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            switch (collisionMethod)
            {
            case 1:
                probeIndex = (hashIndex + i) % size;
                break;
            case 2:
                probeIndex = (hashIndex + i * i) % size;
                break;
            }

            if (Table[probeIndex] != nullptr)
            {
                typename list<Node*>::iterator ite = Table[probeIndex]->begin();
                if ((*ite)->data == key)
                {
                    while(ite != Table [probeIndex]->end())
                    {
                        T3 temp = (*((*ite)->it));
                        cout <<endl<< temp<<endl;
                        ite++;
                    }
                    return;
                }
            }
            i++;
        } 
            cout << "\n\n----------------------------NO RESULTS FOUND------------------------------------\n\n";
    }

    template <class T3>
    void print()
    {
        cout << "\n--------------------------------------------------------------------------------------------------\n\n";
        for (int i = 0; i < size; i++)
        {
            
            if (Table[i] != nullptr)
            {
                cout << "\n--------------------------------------------------------------------------------------------------\n\n";
                typename list<Node*>::iterator ite = Table[i]->begin();
                while (ite != Table[i]->end())
                {
                     T3 temp = (*((*ite)->it));
                     cout << temp<<endl;
                     ite++;
                }
                cout << "\n--------------------------------------------------------------------------------------------------\n\n";
            }
            
        }
        cout << "\n\n--------------------------------------------------------------------------------------------------\n";
    }

    complaint * getComplaint(int key)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            switch (collisionMethod)
            {
            case 1:
                probeIndex = (hashIndex + i) % size;
                break;
            case 2:
                probeIndex = (hashIndex + i * i) % size;
                break;
            }

            if (Table[probeIndex] != nullptr)
            {
                typename list<Node*>::iterator ite = Table[probeIndex]->begin();
                if ((*ite)->data == key)
                {
                    Access<complaint>(key);
                    int id;
                    cout << "\n\nEnter The complaint id to increase priority of : ";
                    cin >> id;
                    while (ite != Table[probeIndex]->end())
                    {
                        complaint* temp = ((*ite)->it);
                        if (temp->complaintID == id)
                        {
                            return temp;
                        }
                        ite++;
                    }
                    return nullptr;
                }
            }
            i++;
        }
        cout << "\n\n----------------------------NO RESULTS FOUND------------------------------------\n\n";
        return nullptr;
    }
};
