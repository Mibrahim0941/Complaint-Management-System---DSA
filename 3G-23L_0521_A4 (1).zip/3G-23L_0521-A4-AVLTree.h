#pragma once
#include"list"
#include"3G-23L_0521-A4-Users.h"
#include<iostream>
#include"3G-23L_0521-A4-UniversalHash.h"
#include"3G-23L_0521-A4-ChainHash.h"
#include"3G-23L_0521-A4-GroupHash.h"
using namespace std;

template<typename T1, typename T2>
class AVLgroup;
template<typename T>
class AVLTree;
using std::string;
template <class T>
/*queue and linkedlist for level order traversal(not needed but i had it already made*/

class LinkedList
{
private:
	class SLNode
	{
	public:
		T data;
		SLNode* next;

		SLNode()
		{
			next = NULL;
		}

		SLNode(T val, SLNode* nptr = 0)
		{
			data = val;
			next = nptr;
		}

	};

	SLNode* head;
	SLNode* tail;

public:
	SLNode* getHead()
	{
		return head;
	}

	T getDataFromHead() const
	{
		if (!isEmpty())
		{
			return head->data;
		}
	}

	LinkedList()
	{
		head = tail = nullptr;
	}

	~LinkedList()
	{
		if (head != nullptr)
		{
			if (head == tail)
			{
				delete head;
				head = tail = nullptr;
			}
			else
			{
				while (head != tail)
				{
					deleteHead();
				}
				delete head;
				head = tail = nullptr;
			}
		}
	}

	bool isEmpty() const
	{
		if (head == nullptr && tail == nullptr)
		{
			return true;
		}
		return false;
	}

	void addtoHead(T val)
	{

		SLNode* temp = new SLNode(val, head);
		head = temp;
		if (tail == nullptr)
		{
			tail = head;
		}
	}

	void deleteHead()
	{
		if (head != nullptr)
		{
			if (tail == head)
			{
				delete head;
				head = tail = nullptr;
			}
			else
			{
				SLNode* temp = head->next;
				delete head;
				head = temp;
			}
		}
	}

	void print()
	{
		SLNode* tmp;
		for (tmp = head; tmp != NULL; tmp = tmp->next)
		{
			cout << tmp->data << " ";
		}
		cout << endl;
	}

	T getDataFromTail() const
	{
		if (!isEmpty())
		{
			return tail->data;
		}
	}

	void addToTail(T val)
	{
		if (tail != nullptr)
		{
			tail->next = new SLNode(val);
			tail = tail->next;
		}
		else
			head = tail = new SLNode(val);
	}
};

template<typename T>
class Queue
{
private:
	LinkedList<T> queue;
	int count;
	int maxcount;

public:
	Queue(int max = 10)
	{
		count = 0;
		maxcount = max;
	}

	bool isEmpty() const
	{
		return queue.isEmpty();
	}

	void enqueue(const T val)
	{
		if (count != maxcount)
		{
			queue.addToTail(val);
			count++;
		}
		else
			cout << "Queue is Full :(\n";
	}

	int size()
	{
		return count;
	}

	void dequeue()
	{
		if (!queue.isEmpty())
		{
			queue.deleteHead();
			count--;
		}
	}

	bool isFull()
	{
		if (count == maxcount)
			return true;
		return false;
	}

	T Front()
	{
		return queue.getDataFromHead();
	}

	T rear()
	{
		return queue.getDataFromTail();
	}

	void print()
	{
		queue.print();
	}

};

/*End of queue and linkedlist*/


/*start of normal AVL tree class with just a single Nodeptr*/
template<typename T>
class AVLTree
{
private:
	struct AVLNode
	{
	public:
		T data;
		list<User*> ::iterator node;
		int height;
		AVLNode* left;
		AVLNode* right;
		AVLNode(T d, AVLNode* l = nullptr, AVLNode* r = nullptr)
		{
			data = d;
			left = l;
			right = r;
			height = -1;
		}
	};
	AVLNode* root;

	list<User*> ::iterator insert(AVLNode*& t, AVLNode* prev, list<User*>& l1 ,User* & temp)
	{
		int x = temp->userID;
		if (t == nullptr)
		{
			t = new AVLNode(x, nullptr, nullptr);
			//User* temp = new User(x);
			if (!prev)
			{
				l1.push_back(temp);
				list<User*> ::iterator it = l1.end();
				it--;
				t->node = it;
				return it;
				//email.insert(temp->email, it);
				/*uid.Insert(x, it);
				U_name.Insert(temp->username, it);
				U_email.Insert(temp->email, it);*/
			}
			else
			{
				if (x < prev->data)
				{
					list<User*> ::iterator it = prev->node;
					l1.insert(it, temp);
					it--;
					t->node = it;
					
					//email.insert(temp->email, it);
					/*uid.Insert(x, it);
					U_name.Insert(temp->username, it);
					U_email.Insert(temp->email, it);*/
					return it;
				}
				else if (x > prev->data)
				{
					list<User*> ::iterator it = prev->node;
					if (it == l1.end())
					{
						l1.push_back(temp);
						it = l1.end();
						it--;
						t->node = it;
						//email.insert(temp->email, it);
						/*uid.Insert(x, it);
						U_name.Insert(temp->username, it);
						U_email.Insert(temp->email, it);*/

					}
					else
					{
						it++;
						l1.insert(it, temp);
						it--;
						t->node = it;
						//email.insert(temp->email, it);
						/*uid.Insert(x, it);
						U_name.Insert(temp->username, it);
						U_email.Insert(temp->email, it);*/
					}
					return it;
				}
			}

		}
		else if (x < t->data)
			return insert(t->left, t, l1, temp);
		else if (t->data < x)
			return insert(t->right, t, l1, temp);
		balance(t);
	}

	void removefromlist(const int& x, AVLNode*& t, list<User*>& l1)
	{
		if (t == nullptr)
			return;
		if (x < t->data)
			removefromlist(x, t->left, l1);
		else if (t->data < x)
			removefromlist(x, t->right, l1);
		else if (t->left != nullptr && t->right != nullptr)
		{
			t->data = findMin(t->right)->data;
			swap(t->node, findMin(t->right)->node);
			removefromlist(t->data, t->right, l1);
		}
		else
		{
			AVLNode* oldNode = t;
			l1.erase(oldNode->node);
			if (t->left != nullptr)
				t = t->left;
			else
				t = t->right;
			delete oldNode;
		}
		balance(t);
	}

	void remove(const T& x, AVLNode*& t)
	{
		if (t == nullptr)
			return;
		if (x < t->data)
			remove(x, t->left);
		else if (t->data < x)
			remove(x, t->right);
		else if (t->left != nullptr && t->right != nullptr)
		{
			t->data = findMin(t->right)->data;
			swap(t->node, findMin(t->right)->node);
			remove(t->data, t->right);
		}
		else
		{
			AVLNode* oldNode = t;
			if (t->left != nullptr)
				t = t->left;
			else
				t = t->right;
			delete oldNode;
		}
		balance(t);
	}

	void balance(AVLNode*& x)
	{
		if (x == nullptr)
			return;
		if (height(x->right) - height(x->left) < -1)
		{
			if (height(x->left->left) >= height(x->left->right))
				rightRotate(x);
			else
				doubleLeftRightRotation(x);
		}
		else if (height(x->right) - height(x->left) > 1)
		{
			if (height(x->right->right) >= height(x->right->left))
				leftRotate(x);
			else
				doubleRightLeftRotation(x);
		}
		x->height = max(height(x->left), height(x->right)) + 1;
	}

	int height(AVLNode* nodeptr)
	{
		if (nodeptr == nullptr)
		{
			return -1;
		}
		int left = -1, right = -1;
		if (nodeptr->left)
			left = nodeptr->left->height;
		if (nodeptr->right)
			right = nodeptr->right->height;
		return max(left, right) + 1;
	}

	void rightRotate(AVLNode*& x)
	{
		AVLNode* orphan = x->left->right;
		AVLNode* y = x->left;
		y->right = x;
		x->left = orphan;
		x->height = height(x);
		y->height = height(y);
		x = y;
	}

	void leftRotate(AVLNode*& x)
	{
		AVLNode* orphan = x->right->left;
		AVLNode* y = x->right;
		y->left = x;
		x->right = orphan;
		x->height = height(x);
		y->height = height(y);
		x = y;
	}

	void doubleLeftRightRotation(AVLNode*& X)
	{
		leftRotate(X->left);
		rightRotate(X);
	}

	void doubleRightLeftRotation(AVLNode*& X)
	{
		rightRotate(X->right);
		leftRotate(X);
	}

	void printLevelOrder(AVLNode* root)
	{
		if (root == nullptr)
			return;
		Queue<AVLNode*> q;
		q.enqueue(root);
		while (q.isEmpty() == false)
		{
			AVLNode* nod = q.Front();
			cout << *(nod->node) << " ";
			cout << endl;

			cout << endl;
			q.dequeue();
			if (nod->left != nullptr)
				q.enqueue(nod->left);
			if (nod->right != nullptr)
				q.enqueue(nod->right);
		}
	}

	AVLNode* findMin(AVLNode*& x)
	{
		if (x->left == nullptr)
			return x;
		else
			findMin(x->left);

	}

	AVLNode* search(AVLNode* node, T d)
	{
		if (node)
		{
			if (node->data > d)
				return search(node->left, d);
			else if (node->data < d)
				return search(node->right, d);
			else
				return node;
		}
		else
			return nullptr;
	}

	void insert(string x, AVLNode*& t, list<User*> ::iterator it)
	{
		if (t == nullptr)
		{
			t = new AVLNode(x, nullptr, nullptr);
			t->node = it;
		}
		else if (x < t->data)
			insert(x, t->left, it);
		else if (t->data < x)
			insert(x, t->right, it);
		balance(t);
	}
public:
	void insert(string data, list<User*> ::iterator it)
	{
		insert(data, root, it);
	}

	AVLTree()
	{
		root = nullptr;
	}

	void Print()
	{
		printLevelOrder(root);
	}

	list<User*>::iterator insert(list<User*>& l1)
	{
		User* newuser = new User;
		return insert(root, 0, l1, newuser);
	}

	void remove(T data)
	{
		remove(data, root);
	}

	void removefromlist(int data, list<User*>& l1)
	{
		removefromlist(data, root, l1);
	}

	void search(T data)
	{
		cout << endl << endl << "-----------------------------------------------SEARCH RESULTS------------------------------------------------\n\n";
		AVLNode* temp = search(root, data);
		if (temp)
			cout << *(temp->node);
		else
			cout << "No User Found :(";
		cout << endl << "-------------------------------------------------------------------------------------------------------------\n\n";
	}

	User* searchUser(T data)
	{
		AVLNode* temp = search(root, data);
		if (temp)
			return *(temp->node);
		else return nullptr;
		
	}

	void DeleteData(T data , AVLTree<int>& index, list<User*>& l1, AVLgroup<std::string, list<User*>::iterator>& country, AVLgroup<string, list<User*>::iterator>& Type, UniversalHash<int>& uid, ChainHash& uname, ChainHash& uemail, GroupHash<string, list<User*>::iterator>& ucountry, GroupHash<string, list<User*>::iterator>& utype);
};
/*End of normal AVL class*/

/*start of group avl class that has a linked list of iterators for group based avls*/
template<typename T,typename T2>
class AVLgroup
{
private:
	struct AVLNode
	{
	public:
		T data;
		list<T2> group;
		int height;
		AVLNode* left;
		AVLNode* right;
		AVLNode(T d, AVLNode* l = nullptr, AVLNode* r = nullptr)
		{
			data = d;
			left = l;
			right = r;
			height = -1;
		}
	};
	AVLNode* root;

public:
	AVLgroup()
	{
		root = nullptr;
	}

	void insert(T x, AVLNode*& t, T2 it)
	{
		if (t == nullptr)
		{
			t = new AVLNode(x, nullptr, nullptr);
			(t->group).push_back(it);
		}
		else if (x < t->data)
			insert(x, t->left, it);
		else if (t->data < x)
			insert(x, t->right, it);
		balance(t);
	}

	void remove(const string& x, AVLNode*& t)
	{
		if (t == nullptr)
			return;
		if (x < t->data)
			remove(x, t->left);
		else if (t->data < x)
			remove(x, t->right);
		else if (t->left != nullptr && t->right != nullptr)
		{
			t->data = findMin(t->right)->data;
			t->group = findMin(t->right)->group;
			remove(t->data, t->right);
		}
		else
		{
			AVLNode* oldNode = t;
			if (t->left != nullptr)
				t = t->left;
			else
				t = t->right;
			delete oldNode;
		}
		balance(t);
	}

	void balance(AVLNode*& x)
	{
		if (x == nullptr)
			return;
		if (height(x->right) - height(x->left) < -1)
		{
			if (height(x->left->left) >= height(x->left->right))
				rightRotate(x);
			else
				doubleLeftRightRotation(x);
		}
		else if (height(x->right) - height(x->left) > 1)
		{
			if (height(x->right->right) >= height(x->right->left))
				leftRotate(x);
			else
				doubleRightLeftRotation(x);
		}
		x->height = max(height(x->left), height(x->right)) + 1;
	}

	int height(AVLNode* nodeptr)
	{
		if (nodeptr == nullptr)
		{
			return -1;
		}
		int left = -1, right = -1;
		if (nodeptr->left)
			left = nodeptr->left->height;
		if (nodeptr->right)
			right = nodeptr->right->height;
		return max(left, right) + 1;
	}

	void rightRotate(AVLNode*& x)
	{
		AVLNode* orphan = x->left->right;
		AVLNode* y = x->left;
		y->right = x;
		x->left = orphan;
		x->height = height(x);
		y->height = height(y);
		x = y;
	}

	void leftRotate(AVLNode*& x)
	{
		AVLNode* orphan = x->right->left;
		AVLNode* y = x->right;
		y->left = x;
		x->right = orphan;
		x->height = height(x);
		y->height = height(y);
		x = y;
	}

	void doubleLeftRightRotation(AVLNode*& X)
	{
		leftRotate(X->left);
		rightRotate(X);
	}

	void doubleRightLeftRotation(AVLNode*& X)
	{
		rightRotate(X->right);
		leftRotate(X);
	}

	void printLevelOrder(AVLNode* root)
	{
		if (root == nullptr)
			return;
		Queue<AVLNode*> q;
		q.enqueue(root);
		while (q.isEmpty() == false)
		{
			AVLNode* node = q.Front();
			cout << "Search Field : " << node->data << "\n";
			search(node->data);
			cout << endl;
			q.dequeue();
			if (node->left != nullptr)
				q.enqueue(node->left);
			if (node->right != nullptr)
				q.enqueue(node->right);
		}
	}

	void PrintLevelOrder()
	{
		printLevelOrder(root);
	}

	void insert(T data, T2 it)
	{
		insert(data, root, it);
	}

	void insertinAVL(T data, T2 it)
	{
		AVLNode* temp = search(root, data);
		if (!temp)
			insert(data, it);
		else
			temp->group.push_back(it);
	}
	AVLNode* findMin(AVLNode*& x)
	{
		if (x->left == nullptr)
			return x;
		else
			findMin(x->left);

	}

	void remove(T data)
	{
		remove(data, root);
	}

	AVLNode* search(AVLNode* node, T d)
	{
		if (node)
		{
			if (node->data > d)
				return search(node->left, d);
			else if (node->data < d)
				return search(node->right, d);
			else
				return node;
		}
		else
			return nullptr;
	}

	void createAVL(list<User*>& l1)
	{
		T2 it = l1.begin();
		while (it != l1.end())
		{
			User* tempuser = *it;
			AVLNode* temp = search(root, tempuser->Country);
			if (!temp)
			{
				insert(tempuser->Country, it);
			}
			else
				(temp->group).push_back(it);
			it++;
		}
	}

	void createTypeAVL(list<User*>& l1)
	{
		T2 it = l1.begin();
		while (it != l1.end())
		{
			User* tempuser = *it;
			AVLNode* temp = search(root, tempuser->Type);
			if (!temp)
			{
				insert(tempuser->Type, it);
			}
			else
				(temp->group).push_back(it);
			it++;
		}
	}

	void search(T data)
	{
		AVLNode* temp = search(root, data);
		if (temp)
		{
			typename list<T2> ::iterator it = (temp->group).begin();
			cout << "----------------------------------------------------------------------------------------------------------------------- \n";
			while (it != (temp->group).end())
			{
				cout << *(*it);
				cout << endl;
				it++;
			}
			cout << "----------------------------------------------------------------------------------------------------------------------- \n";
		}
		else
			cout << "No Record Found\n";
	}

	void deletefromgroup(string data, T2 it)
	{
		AVLNode* temp = search(root, data);
		typename list<T2> ::iterator it2 = (temp->group).begin();
		bool flag = true;
		while (it2 != (temp->group).end() && flag)
		{
			if ((*it2) == it)
			{
				(temp->group).erase(it2);
				if ((temp->group).size() == 0)
				{
					remove(data);
				}
				return;
			}
			it2++;
		}
	}

	void deleteGroup(T data, AVLTree<string>& name, AVLTree<string>& email, AVLTree<int>& index, list<User*>& l1, AVLgroup<string,T2>& country, AVLgroup<string, T2>& Type)
	{
		AVLNode* temp = search(root,data);
		if (temp)
		{
			list< T2>  hmm = temp->group;
			typename list< T2>::iterator it = hmm.begin();
			while (it != hmm.end())
			{
				User* tempuser = *(*it);
				name.remove(tempuser->username);
				email.remove(tempuser->email);
				//country.deletefromgroup(tempuser->Country, temp->node);
				Type.deletefromgroup(tempuser->Type, *it);
				index.removefromlist(tempuser->userID, l1);
				it++;
			}
			remove(data);
		}
	}

	void deleteGroupbyType(T data, AVLTree<string>& name, AVLTree<string>& email, AVLTree<int>& index, list<User*>& l1, AVLgroup& country, AVLgroup& Type)
	{
		AVLNode* temp = search(root,data);
		if (temp)
		{
			list<T2>  hmm = temp->group;
			typename list< T2>::iterator it = hmm.begin();
			while (it != hmm.end())
			{
				User* tempuser = *(*it);
				name.remove(tempuser->username);
				email.remove(tempuser->email);
				country.deletefromgroup(tempuser->Country, *it);
				//Type.deletefromgroup(tempuser->Type, it);
				index.removefromlist(tempuser->userID, l1);
				it++;
			}
			remove(data);
		}
	}
};
/*End of group AVL*/


/*A function of normal AVL that is forward declared due to compatibility issues. it deletes a data based on any attribute and upddates other trees andd list as well */
template<typename T>
void AVLTree<T>::DeleteData(T data, AVLTree<int>& index, list<User*>& l1, AVLgroup<std::string, list<User*>::iterator>& country, AVLgroup<string, list<User*>::iterator>& Type, UniversalHash<int>& uid, ChainHash& uname, ChainHash& uemail, GroupHash<string, list<User*>::iterator> & ucountry, GroupHash<string, list<User*>::iterator>& utype)
{
	AVLNode* temp = search(root, data);
	if (temp)
	{
		User* tempuser = *(temp->node);
		/*name.remove(tempuser->username);
		email.remove(tempuser->email);*/
		country.deletefromgroup(tempuser->Country, temp->node);
		Type.deletefromgroup(tempuser->Type, temp->node);

		uname.Delete(tempuser->username);
		uemail.Delete(tempuser->email);
		uid.Delete(tempuser->userID);
		ucountry.Delete(tempuser->Country, tempuser->username);
		utype.Delete(tempuser->Type, tempuser->username);
		index.removefromlist(tempuser->userID, l1);

		cout << "Data Deleted Successfully";
	}
	else
		cout << "No Record Found";
}