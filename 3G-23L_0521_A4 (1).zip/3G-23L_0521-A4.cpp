#include"3G-23L_0521-A4-Users.h"
#include"3G-23L_0521-A4-AVLTree.h"
#include"list"
#include"3G-23L_0521-A4-Binaryheap.h"
#include"3G-23L_0521-A4-UniversalHash.h"
#include "3G-23L_0521-A4-ChainHash.h"
#include"3G-23L_0521-A4-GroupHash.h"
class UserList
{
private:
	list<User*> List;
	AVLTree<int> UserID;
	//AVLTree<string> email;
	AVLgroup<string,  list<User*>::iterator>* Country;
	AVLgroup<string, typename list<User*>::iterator>* Type;
	
	AVLgroup<int, complaint*> ComplainsID;
	AVLgroup<string, complaint*> ComplainsCountry;

	UniversalHash<int> U_id;
	ChainHash U_name;
	ChainHash U_email;
	GroupHash<string, list<User*>::iterator> U_Country;
	GroupHash<string, list<User*>::iterator> U_Type;
	Heap PriorityQueue;
	GroupHash<int, complaint*> IDcomplains;
	GroupHash<string, complaint*> CountryComplains;

public:
	UserList()     //constructor
	{
		Country = nullptr;
		Type = nullptr;
		U_Country.setMethod(1);
		U_Type.setMethod(2);
		IDcomplains.setMethod(2);
		CountryComplains.setMethod(2);
	}

	void Insert()     //repeatedly ask user if he wants to enter a new user. and adds it. otherwise exits
	{
		cout << "\nDo you Want to insert a new user (0 to exit, 1 to insert): ";
		int choice;
		cin >> choice;
		cin.ignore();
		while(choice==1)
		{
			list<User*>::iterator it = UserID.insert(List);
			U_id.Insert((*it)->userID, it);
			U_name.Insert((*it)->username, it);
			U_email.Insert((*it)->email, it);
			U_Country.Insert((*it)->Country, it);
			U_Type.Insert((*it)->Type, it);

			cout << "\nDo you Want to insert a new user (0 to exit, 1 to insert): ";
			cin >> choice;
			cin.ignore();
		}
	}

	void Delete()                ////repeatedly ask user if he wants to delete a new user.provides 5 options for deletion. otherwise exits     
	{
		int choice;
		bool flag = false;
		cout << "What Deletion Do You Want To Perform\n\n1. Delete By UserID\n2. Delete by Username\n3. Delete by email\n4. Delete by Country\n5. Delete by Type\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
		while(choice!=0)
		{
			while (choice < 1 && choice>6)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			} 
			if (choice == 1)
			{
				cout << "Enter User ID to Delete : ";
				int userid;
				cin >> userid;
				UserID.DeleteData(userid, UserID, List,*Country,*Type, U_id, U_name, U_email, U_Country, U_Type);
			}
			else if (choice == 2)
			{
				cout << "Enter UserName to Delete : ";
				string username;
				cin >> username;
				User* temp = U_name.Access(username);
				U_name.DeleteName(username, U_email, U_id);
				U_Country.Delete(temp->Country, username);
				U_Type.Delete(temp->Type, username);
				UserID.removefromlist(temp->userID, List);
			}
			else if (choice == 3)
			{
				cout << "Enter Email to Delete : ";
				string em;
				cin >> em;
				User* temp = U_email.Access(em);
				U_email.DeleteEmail(em, U_name, U_id);
				U_Country.Delete(temp->Country, em);
				U_Type.Delete(temp->Type,em);
				UserID.removefromlist(temp->userID, List);
			}
			else if (choice == 4)
			{
				cout << "Enter Country to Delete : ";
				string em;
				cin >> em;

				list<User*>* templist = U_Country.Delete(em);
				if (templist)
				{
					list<User*>::iterator it = templist->begin();
					while (it != templist->end())
					{
						U_email.DeleteEmail((*it)->email, U_name, U_id);
						U_Type.Delete((*it)->Type, (*it)->email);
						UserID.removefromlist((*it)->userID, List);
						it++;
					}
					templist->clear();
					delete templist;
				}
				//Country->deleteGroup(em, names, email, UserID, List, *Country, *Type);
			}
			else if (choice == 5)
			{
				cout << "Enter Type to Delete : ";
				string em;
				cin >> em;
				list<User*> *templist = U_Type.Delete(em);
				if(templist)
				{
					list<User*>::iterator it = templist->begin();
					while (it != templist->end())
					{
						U_email.DeleteEmail((*it)->email, U_name, U_id);
						U_Country.Delete((*it)->Country, (*it)->email);
						UserID.removefromlist((*it)->userID, List);
						it++;
					}
					templist->clear();
					delete templist;
				}
				//Type->deleteGroupbyType(em, names, email, UserID, List, *Country, *Type);
			}
			cout << "What Deletion Do You Want To Perform\n\n1. Delete By UserID\n2. Delete by Username\n3. Delete by email\n4. Delete by Country\n5. Delete by Type\n\nEnter Your Choice(0 to exit) : ";
			cin >> choice;
		}
	}

	void search()         //repeatedly ask user if he wants to search a new user.provides 5 options for search. otherwise exits     
	{
		int choice;
		bool flag=false;
		cout << "What Search Do You Want To Perform\n\n1. Search By UserID\n2. Search by Username\n3. Search by email\n4. Search by Country\n5. Search by type\n6. Search Complains By ID\n7. Search Complains by Country\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
		while(choice!=0)
		{
			while (choice < 1 && choice>8)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			}
			if (choice == 1)
			{
				cout << "Enter User ID to search : ";
				int userid;
				cin >> userid;
				//UserID.search(userid);
				User* temp = (U_id.Access(userid));
				if (temp)
				{
					cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
					cout << temp;
					cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
				}
				else cout << "\n\n----------------------------NO RESULTS FOUND------------------------------------\n\n";
			}
			else if (choice == 2)
			{
				cout << "Enter UserName to search : ";
				string username;
				cin >> username;
				//names.search(username);
				User* temp= U_name.Access(username);
				if (temp)
				{
					cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
					cout << temp;
					cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
				}
				else cout << "\n\n----------------------------NO RESULTS FOUND------------------------------------\n\n";
			}
			else if (choice == 3)
			{
				cout << "Enter Email to search : ";
				string em;
				cin >> em;
				//email.search(em);
				User* temp = U_email.Access(em);
				if (temp)
				{
					cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
					cout << temp;
					cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
				}
				else cout << "\n\n----------------------------NO RESULTS FOUND------------------------------------\n\n";
			}
			else if (choice == 4)
			{
				cout << "Enter Country to search : ";
				string em;
				cin >> em;
				cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
				U_Country.Access<User*>(em);
				cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
			}
			else if (choice == 5)
			{
				cout << "Enter Type to search : ";
				string em;
				cin >> em;
				cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
				U_Type.Access<User*>(em);
				cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
			}
			else if (choice == 6)
			{
				cout << "Enter User ID to search Complain : ";
				int em;
				cin >> em;
				cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
				IDcomplains.Access<complaint>(em);
				cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
			}
			else if (choice == 7)
			{
				cout << "Enter Country to search Complain : ";
				string em;
				cin >> em;
				cout << "\n\n---------------------------------------SEARCH RESULT------------------------------------------\n\n";
				CountryComplains.Access<complaint>(em);
				cout << "\n\n--------------------------------------------------------------------------------------------------\n\n";
			}
			cout << "What Search Do You Want To Perform\n\n1. Search By UserID\n2. Search by Username\n3. Search by email\n4. Search by Country\n5. Search by type\n6. Search Complains By ID\n7. Search Complains by Country\n\nEnter Your Choice(0 to exit) : ";
			cin >> choice;
		}
	}

	void CreateCountryAVL()                          //iterates the list and creates a groupAVL based on country
	{
		Country = new AVLgroup<string, list<User*>::iterator>;
		Country->createAVL(List);
	}

	void CreateTypeAVL()            // //iterates the list and creates a groupAVL based on rank
	{
		Type = new AVLgroup<string, list<User*>::iterator>;
		Type->createTypeAVL(List);
	}

	void addComplaint(int id)
	{
		User* temp = U_id.Access(id);
		if (temp)
		{
			complaint* comp = new complaint(temp->userID);
			pair<int, complaint*> x;
			if (temp->Type == "platinum")
			{
				x.first = 0;
			}
			else if (temp->Type == "gold")
			{
				x.first = 1;
			}
			else if (temp->Type == "silver")
			{
				x.first = 2;
			}
			else if (temp->Type == "new")
			{
				x.first = 3;
			}
			else if (temp->Type == "regular")
			{
				x.first = 4;
			}
			x.second = comp;
			PriorityQueue.insert(x);
			IDcomplains.Insert(id, comp);
			CountryComplains.Insert(temp->Country, comp);
			//ComplainsID.insertinAVL(temp->userID, comp);
			//ComplainsCountry.insertinAVL(temp->Country, comp);
			cout << "\nComplaint Added Successfully\n\n";
		}
		else cout << "No User Exists";
	}

	void RegisterComplain()
	{
		cout << "\n Enter Your ID : ";
		int id;
		cin >> id;
		cin.ignore();
		addComplaint(id);
	}

	void serviceComplaint()
	{
		pair<int, complaint*> x = PriorityQueue.getMin();
		PriorityQueue.deleteMin();
		cout << "complaint with Details : \n" << x.second << "\nServiced successfully";
	}

	void increasePriority(int id)
	{
		complaint* temp = IDcomplains.getComplaint(id);
		PriorityQueue.increasePriority(temp);
	}

	void Display()
	{
		int choice;
		bool flag = false;
		cout << "What Display Do You Want To Perform\n\n1. Display By UserID\n2. Display by Username\n3. Display by email\n4. Display by Country\n5. Display by type\n6.Display by complains of User\n7.Display by Complains in Country\n\nEnter Your Choice(0 to Exit) : ";
		cin >> choice;
		while (choice != 0)
		{
			while (choice < 1 && choice>8)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			}
			if (choice == 1)
			{
				U_id.print();
			}
			else if (choice == 2)
			{
				U_name.print();
				//names.Print();
			}
			else if (choice == 3)
			{
				U_email.print();
				//email.Print();
			}
			else if (choice == 4)
			{
				U_Country.print<User*>();
				//Country->PrintLevelOrder();
			}
			else if (choice == 5)
			{
				U_Type.print<User*>();
				//Type->PrintLevelOrder();
			}
			else if (choice == 6)
			{
				IDcomplains.print<complaint>();
				//ComplainsID.PrintLevelOrder();
			}
			else if (choice == 7)
			{
				CountryComplains.print<complaint>();
				//ComplainsCountry.PrintLevelOrder();
			}
			cout << "What Display Do You Want To Perform\n\n1. Display By UserID\n2. Display by Username\n3. Display by email\n4. Display by Country\n5. Display by type\n6.Display by complains of User\n7.Display by Complains in Country\n\nEnter Your Choice(0 to Exit) : "; 
			cin >> choice;
		}
	}
};

int main()
{
	UserList m1;
	int choice;
	bool flag = false;
	cout << "What Operation Do You Want To Perform\n\n1. Insert User \n2. Search User\n3. Increase Priority of a complaint\n4. Delete User\n5. Display Users\n6. Register Complaint\n7.Service a Complaint\n\nEnter Your Choice(0 to exit) : ";
	cin >> choice;
	while (choice != 0)
	{
		while (choice < 1 && choice>8)
		{
			if (flag)
				cout << "OOPS. Wrong Choice. Please Re Enter : ";
			cin >> choice;
			flag = true;
		}
		if (choice == 1)
		{
			m1.Insert();
		}
		else if (choice == 2)
		{
			m1.search();
		}
		else if (choice == 3)
		{
			int id;
			cout << " Enter User ID : ";
			cin >> id;
			m1.increasePriority(id);
		}
		else if (choice == 4)
		{
			m1.Delete();
		}
		else if (choice == 5)
		{
			m1.Display();
		}
		else if (choice == 6)
		{
			m1.RegisterComplain();
		}
		else if (choice == 7)
		{
			m1.serviceComplaint();
		}
		cout << "What Operation Do You Want To Perform\n\n1. Insert User \n2. Search User\n3. Increase Priority of a complaint\n4. Delete User\n5. Display Users\n6. Register Complaint\n7.Service a Complaint\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
	}

	return 0;
}