#pragma once
#include<iostream>
#include<string>
using namespace std;

enum type
{
	platinum = 0,
	gold,
	silver,
	New,
	regular

};

class complaint
{
public:
	int complaintID;
	int userid;
	string description;
	static int cmpID;
	complaint(int UID)
	{
		complaintID = cmpID++;
		userid = UID;
		cout << "Enter Description of Your Complain : ";
		getline(cin, description);
	}
	friend ostream& operator<<(ostream& out, complaint*& comp);
	friend ostream& operator<<(ostream& out, complaint& user);
};

inline ostream& operator<<(ostream& out,complaint& user)                         //operator<< to print a certain card;
{
	cout << "Complaint ID : " << user.complaintID;
	cout << endl;
	cout << "UserID : " << user.userid;
	cout << endl;
	cout << "Description : " << user.description;
	cout << endl;
	return out;
}

inline ostream& operator<<(ostream& out, complaint*& comp)                         //operator<< to print a certain card;
{
	cout << "Complaint ID : " << comp->complaintID;
	cout << endl;
	cout << "UserID : " << comp->userid;
	cout << endl;
	cout << "Description : " << comp->description;
	cout << endl;
	return out;
}
int complaint::cmpID = 0;