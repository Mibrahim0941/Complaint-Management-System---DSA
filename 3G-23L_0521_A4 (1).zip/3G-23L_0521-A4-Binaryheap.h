#pragma once
#include<vector>
#include"3G-23L_0521-A4-complaints.h"

bool comparegreater(const pair<int, complaint*>& x, const pair<int, complaint*>& y)
{
    if (x.first == y.first)
    {
        if (x.second->complaintID > y.second->complaintID)
        {
            return true;
        }
        else return false;
    }
    else if (x.first > y.first)
    {
        return true;
    }
    else return false;
}

class Heap
{

public:
    Heap() {}

    void insert(const pair<int, complaint*> & x)
    {
        _vector.push_back(x);
        bubble_up(_vector.size() - 1);
    }

    bool isEmpty() const
    {
        return _vector.empty();
    }

    const pair<int, complaint*>& getMin() const
    {
        if (!isEmpty())
        {
            return _vector[0];
        }
        else
        {
            cout << "The heap is empty" << endl;
        }
    }

    void deleteMin()
    {
        if (isEmpty())
        {
            cout << "The heap is empty." << endl;
            return;
        }
        _vector[0] = _vector.back();
        _vector.pop_back();
        bubble_down(0);
    }

    bool deleteAll(pair<int, complaint*> key)
    {
        bool deleted = false;
        for (int i = 0; i < _vector.size(); ++i)
        {
            if (_vector[i] == key)
            {
                _vector[i] = _vector.back();
                _vector.pop_back();
                bubble_down(i);
                deleted = true;
            }
        }
        return deleted;
    }

    void increasePriority(complaint*& T)
    {
        int index = search(T);
        if (index == -1)
            cout << "No Complaint Exists!!";
        else
        {
            swap(_vector[index], _vector[_vector.size() - 1]);
            _vector.pop_back();
            bubble_down(index);
        }
    }

private:
    vector<pair<int, complaint*>> _vector;

    void bubble_up(int i)
    {
        while (i > 0 && comparegreater(_vector[(i - 1) / 2] , _vector[i]))
        {
            swap(_vector[i], _vector[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

    void bubble_down(int i)
    {
        int smallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < _vector.size() && !comparegreater( _vector[left] , _vector[smallest]))
        {
            smallest = left;
        }
        if (right < _vector.size() && !comparegreater( _vector[right] , _vector[smallest]))
        {
            smallest = right;
        }

        if (smallest != i) {
            swap(_vector[i], _vector[smallest]);
            bubble_down(smallest);
        }
    }

    int search(complaint*& T)
    {
        for (int i = 0; i < _vector.size(); i++)
        {
            if (_vector[i].second == T)
                return i;
        }
        return -1;
    }
};

