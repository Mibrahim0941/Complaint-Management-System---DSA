#pragma once
#include<list>
#include<vector>
#include"3G-23L_0521-A4-Users.h"
using namespace std;
template<typename T>
class UniversalHash
{
private:
    struct Node
    {
        int data;
        list<User*> ::iterator it;
        Node(int k, list<User*> ::iterator i)
        {
            data = k;
            it = i;
        }
    };
    int size;
    int count;           
    int prime;
    vector<Node*> Table;

    int hash(int key)
    {
        srand(key);
        int a = rand();
        int b = rand();
        return ((a * key + b) % prime) % size;
    }

    int secondaryHash(int key)
    {
        srand(key);
        int a = rand();
        int b = rand();
        return 1 + ((a * key + b) % (prime)) % (size - 2);
    }

    void rehash()
        {
        	int oldSize = size;
        	size *= 2;
            vector<Node*> oldArr = Table;
            Table.resize(size);
        	for (int i = 0; i < size; i++)
        	{
        		Table[i] = nullptr;
        	}
        	count = 0;
        	for (int i = 0; i < oldSize; i++) 
            {
        		if (oldArr[i] != nullptr) 
        			Insert(oldArr[i]->data,oldArr[i]->it);
        	}
           //delete oldArr;
        }
public:
    UniversalHash(int s = 100) : size(s)
    {
        count = 0;
        prime = 1009;
        Table.resize(size);
        for (int i = 0; i < size; i++)
        {
            Table[i] = nullptr;
        }
    }

    void Insert(int key, list<User*> ::iterator it)
    {
        if ((float(count) / size) > 0.5)
        {
            rehash();
        }

        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size)
        {
            int probeIndex;
            probeIndex = (hashIndex + i * secondaryHash(key)) % size;
            if (Table[probeIndex] == nullptr)
            {
                Table[probeIndex] = new Node(key, it);
                count++;
                return;
            }
            i++;
        }
    }

    void Delete(int key)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size && flag)
        {
            int probeIndex;
            probeIndex = (hashIndex + i * secondaryHash(key)) % size;
            if (Table[probeIndex]->data == key)
            {
                Table[probeIndex] = nullptr;
                count--;
                return;
            }
            else if (Table[probeIndex] == nullptr)
            {
                flag = false;
            }
            i++;
        }
        cout << "Key not found: " << key << endl;
    }

    User* Access(int key)
    {
        int hashIndex = hash(key);
        int i = 0;
        bool flag = true;
        while (i < size && flag)
        {
            int probeIndex;
            probeIndex = (hashIndex + i * secondaryHash(key)) % size;
            if(Table[probeIndex]!=nullptr)
            {
                if (Table[probeIndex]->data == key)
                {
                    return *(Table[probeIndex]->it);
                }
                else if (Table[probeIndex] == nullptr)
                {
                    flag = false; // Key not found
                }
            }

            i++;
        }
        return nullptr;
    }

    void print()
    {
        cout << "\n--------------------------------------------------------------------------------------------------\n\n";
        for (int i = 0; i < size; i++)
        {
            if (Table[i] != nullptr)
            {
               User* temp = *(Table[i]->it);
               cout << temp << endl;
            }
        }
        cout << "\n\n--------------------------------------------------------------------------------------------------\n";
    }
};
