#include"3G-23L_0521-A2-Users.h"
#include"3G-23L_0521-A2-AVLTree.h"
#include"list"
#include"3G-23L_0521-A2-Binaryheap.h"
class UserList
{
private:
	list<User*> List;
	AVLTree<int> UserID;
	AVLTree<string> names;
	AVLTree<string> email;
	AVLgroup<string,  list<User*>::iterator>* Country;
	AVLgroup<string, typename list<User*>::iterator>* Type;
	Heap PriorityQueue;
	AVLgroup<int, complaint*> ComplainsID;
	AVLgroup<string, complaint*> ComplainsCountry;
public:
	UserList()     //constructor
	{
		Country = nullptr;
		Type = nullptr;
	}

	void Insert()     //repeatedly ask user if he wants to enter a new user. and adds it. otherwise exits
	{
		cout << "\nDo you Want to insert a new user (0 to exit, 1 to insert): ";
		int choice;
		cin >> choice;
		cin.ignore();
		while(choice==1)
		{
			UserID.insert(List, names, email);
			cout << "\nDo you Want to insert a new user (0 to exit, 1 to insert): ";
			cin >> choice;
			cin.ignore();
		}
	}

	void Delete()                ////repeatedly ask user if he wants to delete a new user.provides 5 options for deletion. otherwise exits     
	{
		int choice;
		bool flag = false;
		cout << "What Deletion Do You Want To Perform\n\n1. Delete By UserID\n2. Delete by Username\n3. Delete by email\n4. Delete by Country\n5. Delete by Type\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
		while(choice!=0)
		{
			while (choice < 1 && choice>6)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			} 
			if (choice == 1)
			{
				cout << "Enter User ID to Delete : ";
				int userid;
				cin >> userid;
				UserID.DeleteData(userid, names, email, UserID, List,*Country,*Type);
			}
			else if (choice == 2)
			{
				cout << "Enter UserName to Delete : ";
				string username;
				cin >> username;
				names.DeleteData(username, names, email, UserID, List, *Country, *Type);
			}
			else if (choice == 3)
			{
				cout << "Enter Email to Delete : ";
				string em;
				cin >> em;
				email.DeleteData(em, names, email, UserID, List, *Country, *Type);
			}
			else if (choice == 4)
			{
				cout << "Enter Country to Delete : ";
				string em;
				cin >> em;
				Country->deleteGroup(em, names, email, UserID, List, *Country, *Type);
			}
			else if (choice == 5)
			{
				cout << "Enter Type to Delete : ";
				string em;
				cin >> em;
				Type->deleteGroupbyType(em, names, email, UserID, List, *Country, *Type);
			}
			cout << "What Deletion Do You Want To Perform\n\n1. Delete By UserID\n2. Delete by Username\n3. Delete by email\n4. Delete by Country\n5. Delete by Type\n\nEnter Your Choice(0 to exit) : ";
			cin >> choice;
		}
	}

	void search()         //repeatedly ask user if he wants to search a new user.provides 5 options for search. otherwise exits     
	{
		int choice;
		bool flag=false;
		cout << "What Search Do You Want To Perform\n\n1. Search By UserID\n2. Search by Username\n3. Search by email\n4. Search by Country\n5. Search by type\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
		while(choice!=0)
		{
			while (choice < 1 && choice>8)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			}
			if (choice == 1)
			{
				cout << "Enter User ID to search : ";
				int userid;
				cin >> userid;
				UserID.search(userid);
			}
			else if (choice == 2)
			{
				cout << "Enter UserName to search : ";
				string username;
				cin >> username;
				names.search(username);
			}
			else if (choice == 3)
			{
				cout << "Enter Email to search : ";
				string em;
				cin >> em;
				email.search(em);
			}
			else if (choice == 4)
			{
				cout << "Enter Country to search : ";
				string em;
				cin >> em;
				Country->search(em);
			}
			else if (choice == 5)
			{
				cout << "Enter Type to search : ";
				string em;
				cin >> em;
				Type->search(em);
			}
			else if (choice == 6)
			{
				cout << "Enter User ID to search Complain : ";
				int em;
				cin >> em;
				ComplainsID.search(em);
			}
			else if (choice == 7)
			{
				cout << "Enter Country to search Complain : ";
				string em;
				cin >> em;
				ComplainsCountry.search(em);
			}
			cout << "What Search Do You Want To Perform\n\n1. Search By UserID\n2. Search by Username\n3. Search by email\n4. Search by Country\n5. Search by type\n\nEnter Your Choice(0 to Exit) : ";
			cin >> choice;
		}
	}

	void CreateCountryAVL()                          //iterates the list and creates a groupAVL based on country
	{
		Country = new AVLgroup<string, list<User*>::iterator>;
		Country->createAVL(List);
	}

	void CreateTypeAVL()            // //iterates the list and creates a groupAVL based on rank
	{
		Type = new AVLgroup<string, list<User*>::iterator>;
		Type->createTypeAVL(List);
	}

	void addComplaint(int id)
	{
		User* temp = UserID.searchUser(id);
		if (temp)
		{
			complaint* comp = new complaint(temp->userID);
			pair<int, complaint*> x;
			if (temp->Type == "platinum")
			{
				x.first = 0;
			}
			else if (temp->Type == "gold")
			{
				x.first = 1;
			}
			else if (temp->Type == "silver")
			{
				x.first = 2;
			}
			else if (temp->Type == "new")
			{
				x.first = 3;
			}
			else if (temp->Type == "regular")
			{
				x.first = 4;
			}
			x.second = comp;
			PriorityQueue.insert(x);
			
			ComplainsID.insertinAVL(temp->userID, comp);
			ComplainsCountry.insertinAVL(temp->Country, comp);
		}
		else cout << "No User Exists";
	}

	void RegisterComplain()
	{
		cout << "\n Enter Your ID : ";
		int id;
		cin >> id;
		cin.ignore();
		addComplaint(id);
		cout << "\n\ncomplaint with UserID = " << id << " Added Successfully\n\n";
	}

	void serviceComplaint()
	{
		PriorityQueue.getMin();
		PriorityQueue.deleteMin();
		cout << "\n\nComplain serviced Successfully\n\n";
	}

	void Display()
	{
		int choice;
		bool flag = false;
		cout << "What Display Do You Want To Perform\n\n1. Display By UserID\n2. Display by Username\n3. Display by email\n4. Display by Country\n5. Display by type\n6.Display by complains of User\n7.Display by Complains in Country\n\nEnter Your Choice(0 to Exit) : "; cin >> choice;
		cin >> choice;
		while (choice != 0)
		{
			while (choice < 1 && choice>8)
			{
				if (flag)
					cout << "OOPS. Wrong Choice. Please Re Enter : ";
				cin >> choice;
				flag = true;
			}
			if (choice == 1)
			{
				UserID.Print();
			}
			else if (choice == 2)
			{
				names.Print();
			}
			else if (choice == 3)
			{
				email.Print();
			}
			else if (choice == 4)
			{
				Country->PrintLevelOrder();
			}
			else if (choice == 5)
			{
				Type->PrintLevelOrder();
			}
			else if (choice == 6)
			{
				ComplainsID.PrintLevelOrder();
			}
			else if (choice == 7)
			{
				ComplainsCountry.PrintLevelOrder();
			}
			cout << "What Display Do You Want To Perform\n\n1. Display By UserID\n2. Display by Username\n3. Display by email\n4. Display by Country\n5. Display by type\n6.Display by complains of User\n7.Display by Complains in Country\n\nEnter Your Choice(0 to Exit) : "; cin >> choice;
			cin >> choice;
		}
	}

	void increasePriority()
	{
		cout << "Enter Complaint ID : ";
		int id;
		cin >> id;
		//PriorityQueue.increasePriority(temp);
		cout << "\n\nPriority Increased And Complained Serviced Successfully\n\n";
	}
};

int main()
{
	UserList m1;
	/*m1.Insert();
	m1.CreateCountryAVL();
	m1.CreateTypeAVL();
	m1.addComplaint(0);
	m1.addComplaint(1);
	m1.addComplaint(2);
	m1.addComplaint(3);
	m1.serviceComplaint();
	m1.serviceComplaint();
	m1.serviceComplaint();
	m1.serviceComplaint();
	m1.search();

	m1.Delete();*/


	int choice;
	bool flag = false;
	cout << "What Operation Do You Want To Perform\n\n1. Insert User \n2. Search User\n3. Create Group Indices\n4. Delete User\n5. Display Users\n6. Register Complaint\n7. Service a Complaint\n8. Increase Priority of a complaint\n\nEnter Your Choice(0 to exit) : ";
	cin >> choice;
	while (choice != 0)
	{
		while (choice < 1 && choice>9)
		{
			if (flag)
				cout << "OOPS. Wrong Choice. Please Re Enter : ";
			cin >> choice;
			flag = true;
		}
		if (choice == 1)
		{
			m1.Insert();
			m1.CreateCountryAVL();
			m1.CreateTypeAVL();
		}
		else if (choice == 2)
		{
			m1.search();
		}
		else if (choice == 3)
		{
			m1.CreateCountryAVL();
			m1.CreateTypeAVL();
		}
		else if (choice == 4)
		{
			m1.Delete();
		}
		else if (choice == 5)
		{
			m1.Display();
		}
		else if (choice == 6)
		{
			m1.RegisterComplain();
		}
		else if (choice == 7)
		{
			m1.serviceComplaint();
		}

		else if (choice == 8)
		{
			m1.increasePriority();
		}
		cout << "What Operation Do You Want To Perform\n\n1. Insert User \n2. Search User\n3. Create Group Indices\n4. Delete User\n5. Display Users\n6. Register Complaint\n7. Service a Complaint\n8. Increase Priority of a complaint\n\nEnter Your Choice(0 to exit) : ";
		cin >> choice;
	}

	return 0;
}